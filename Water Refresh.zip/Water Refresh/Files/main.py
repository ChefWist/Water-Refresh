# modules
import pygame
from sys import exit
from random import randint



pygame.init() # Starts Pygame
pygame.mixer.init()

# Functions 

def buy(price,give,type):
  global current_score 
  if current_score >= price:
    current_score -= price
    type += give
  return type
    

# Creates all cubes
def cubes(type,rects):
  global display_type # selects the display type
  global score # selects score
  global high_score # selects high score
  global total_earned # selects total earnes
  global ice_speed
  global current_score
  global ice_cubes
  global ice_cubes_rects
  idx = 0 #index
  for i in ice_cubes_rects: # loops through list
    i = ice_cubes_rects[idx]
    i.y += ice_speed # makes it fall down
    if i.bottom >= 300: # checks if death
      display_type = 1 # changes to main menu
      ice_cubes = []
      ice_cubes_rects = []
      break
      #splash_sound.play(loops=0, fade_ms=0, maxtime=0)
    if ice_cubes_rects[idx].colliderect(cup_rect): # checks collect ice
      del ice_cubes_rects[idx] # deletes ice
      del ice_cubes[idx] # deletes ice
      score += 1 # adds score
      total_earned += 1 # add to total earned
      current_score += 1
      if score > high_score: # checks to make a new high score
        high_score = score
      
    DISPLAY.blit(ice_cubes[idx],i) # shows ice on screen
    idx+=1 # increases index

# Sets up
DISPLAY = pygame.display.set_mode((400, 300)) # Creates a display
pygame.display.set_caption('Water Refresh') # Sets title
clock = pygame.time.Clock() # Creates a clock
display_type = 1 # shows correct screen : 0 = game, 1 = menu, 2 = shop, 3 = stats
high_score = 0  # high score 
total_earned = 0 # total earned 
score = 0 # score 
playtime = 0 # playtime
current_score = 0

# creates bg
background = pygame.image.load("background.png").convert_alpha() # Loads bg image
background = pygame.transform.scale(background, (400, 300)) # Scales bg
bg_rect = background.get_rect(topleft = (0,0)) # places bg

# creates cup
cup = pygame.image.load("cup.png").convert_alpha() # Loads cup image
cup_rect = cup.get_rect(center = (200, 250)) # places cup

#Creates Ice cube
ice = pygame.image.load("ice.png").convert_alpha() # Loads ice image
ice_speed = 2

ice_cubes = [] # types of ice
ice_cubes_rects = [] # ice rectangles

ice_timer = pygame.USEREVENT + 1 # timer
pygame.time.set_timer(ice_timer, 1800) # starts timer

# sounds
#splash_sound = pygame.mixer.Sound("splash.wav")
#splash_sound.play(maxtime=3000)

# Score Display / Font
font = pygame.font.Font("font.ttf", 50) # creates font
stats_font = pygame.font.Font("font.ttf", 25) # smaller font
display_score = font.render(f"Score: {score}", False, "White") # score display
display_score_rect = display_score.get_rect(center = (200, 50))

score_current = stats_font.render(f"Score: {current_score}", False, "White")
score_current_rect = score_current.get_rect(center = (200, 25))

display_high_score = stats_font.render(f"High Score: {high_score}", False, "White") # high score
display_high_score_rect = display_high_score.get_rect(midleft = (25, 50))

display_total_score = stats_font.render(f"Total Score: {total_earned}", False, "White") # total score
display_total_score_rect = display_high_score.get_rect(midleft = (25, 80))

display_playtime = stats_font.render(f"Playtime: {playtime}", False, "White") # playtime
display_playtime_rect = display_playtime.get_rect(midleft = (25, 110))

display_fps = stats_font.render(f"FPS: {round(clock.get_fps())}", False, "White") # fps
display_fps_rect = display_fps.get_rect(midleft = (25, 140))

# Title display 
title = font.render("Water Refresh", False, "White") # name of game
title_rect = title.get_rect(center = (200, 50))

# main menu buttons
# play button
play_button = pygame.image.load("PLAYBUTTON.png").convert_alpha() # creates play button
play_button = pygame.transform.scale(play_button, (100, 50)) # scales button
play_button_rect = play_button.get_rect(center = (200, 100)) # creates rectangle
# Stats button
stats_button = pygame.image.load("STATSBUTTON.png").convert_alpha() # creates stats button
stats_button = pygame.transform.scale(stats_button, (100, 50)) # scales button
stats_button_rect = stats_button.get_rect(center = (200, 220)) # creates rectangle
# back button
back_button = pygame.image.load("BACKBUTTON.png").convert_alpha() # creates back button
back_button = pygame.transform.scale(back_button, (50,25)) # scales button
back_button_rect = back_button.get_rect(topleft = (0, 0)) # creates rectangle
# shop button
shop_button = pygame.image.load("SHOPBUTTON.png").convert_alpha() # creates shop button
shop_button = pygame.transform.scale(shop_button, (100,50)) # scales button
shop_button_rect = shop_button.get_rect(center = (200, 160)) # creates rectangle

# shop
fast = 0
slow = 0

slow_power = pygame.image.load("Slow.png").convert_alpha()
slow_power = pygame.transform.scale(slow_power, (50,50))
slow_power_rect = slow_power.get_rect(topleft = (0, 30))
slow_power_text = stats_font.render(f"25 Money, Owned: {slow}", False, "White")
slow_power_text_rect = slow_power_text.get_rect(topleft = (55, 35))

fast_power = pygame.image.load("Fast.png").convert_alpha()
fast_power = pygame.transform.scale(fast_power, (50,50))
fast_power_rect = fast_power.get_rect(topleft = (0, 85))
fast_power_text = stats_font.render(f"5 Money, Owned: {fast}", False, "White")
fast_power_text_rect = fast_power_text.get_rect(topleft = (55, 90))

slow_power_game = slow_power.get_rect(bottomright = (400, 300))
fast_power_game = fast_power.get_rect(bottomright = (345, 300))



while True: # game loop

  #events
  for event in pygame.event.get():
    #Checks Quit (X button)
    if event.type == pygame.QUIT:
        pygame.quit()
        exit()
    if display_type == 0: # game
        #Creates new ice cube
        if event.type == ice_timer:
            ice_cubes.append(ice)
            ice_cubes_rects.append(ice.get_rect(center = (randint(20,380),-50)))
        if event.type == pygame.MOUSEBUTTONDOWN:
          if slow_power_game.collidepoint(event.pos):
            if slow > 0:
              slow -= 1
              ice_speed = 1
          if fast_power_game.collidepoint(event.pos):
            if fast > 0:
              fast -= 1
              ice_speed = 3
    elif display_type == 1: # main menu
        
        if event.type == pygame.MOUSEBUTTONDOWN: # checks if mouse is clicked
            if play_button_rect.collidepoint(event.pos): # checks clicked play
              ice_cubes = [] # resets everything
              ice_cubes_rects = []
              score = 0
              display_type = 0 # changes display to game
            if stats_button_rect.collidepoint(event.pos):
              display_type = 3 
            if shop_button_rect.collidepoint(event.pos):
              display_type = 2
            if back_button_rect.collidepoint(event.pos): # clicked back button
              display_type = 1
    elif display_type == 2:
      if event.type == pygame.MOUSEBUTTONDOWN: # mouse down
        if back_button_rect.collidepoint(event.pos): # clicked back button
          display_type = 1
        if slow_power_rect.collidepoint(event.pos):
          slow = buy(price=25,give=1,type=slow)
        if fast_power_rect.collidepoint(event.pos):
          fast = buy(price=5,give=1,type=fast)
    else:
      if event.type == pygame.MOUSEBUTTONDOWN and back_button_rect.collidepoint(event.pos):
        display_type = 1

  
  if display_type == 0: # game
    # Shows assets
    DISPLAY.blit(background, bg_rect) # shows bg
    DISPLAY.blit(display_score, display_score_rect) # shows score
    DISPLAY.blit(display_score, display_score_rect)

    # Cup
    cup_rect.x = pygame.mouse.get_pos()[0] # moves cup to mouse x
    DISPLAY.blit(cup, cup_rect) # shows cup

    # Ice
    cubes(ice_cubes, ice_cubes_rects) # places all cubes
    display_score = font.render(f"Score: {score}", False, "White") # updates score
    display_high_score = stats_font.render(f"High Score: {high_score}", False, "White") # updates high score
    display_total_score = stats_font.render(f"Total Score: {total_earned}", False, "White") # updates total score

    # powers 
    DISPLAY.blit(slow_power, slow_power_game)
    DISPLAY.blit(fast_power, fast_power_game)

  
  elif display_type == 2:
    # shop
    DISPLAY.blit(background, bg_rect) # places bg
    DISPLAY.blit(back_button, back_button_rect) # places back button
    slow_power_text = stats_font.render(f"25 Money, Owned: {slow}", False, "White")
    fast_power_text = stats_font.render(f"5 Money, Owned: {fast}", False, "White")
    DISPLAY.blit(slow_power, slow_power_rect)
    DISPLAY.blit(slow_power_text, slow_power_text_rect)
    DISPLAY.blit(fast_power, fast_power_rect)
    DISPLAY.blit(fast_power_text, fast_power_text_rect)
    score_current = stats_font.render(f"Score: {current_score}", False, "White")
    DISPLAY.blit(score_current, score_current_rect)
  elif display_type == 3:
    # stats
    DISPLAY.blit(background, bg_rect) # places bg
    DISPLAY.blit(back_button, back_button_rect) # places back button
    DISPLAY.blit(display_high_score, display_high_score_rect) # places high score
    DISPLAY.blit(display_total_score, display_total_score_rect) # places total score
    DISPLAY.blit(display_playtime, display_playtime_rect) # places playtime
    DISPLAY.blit(display_fps, display_fps_rect) # places fps
  elif display_type == 1:
    # menu
    ice_speed = 2
    DISPLAY.blit(background,bg_rect) # places bg
    DISPLAY.blit(title, title_rect) # places title
    DISPLAY.blit(play_button, play_button_rect) # places play button
    DISPLAY.blit(shop_button, shop_button_rect) # places shop button
    DISPLAY.blit(stats_button, stats_button_rect) # places stats button
    
  # Updates screen
  pygame.display.update()

  # Fps control / timer
  clock.tick(60) # average fps
  playtime = round(pygame.time.get_ticks() / 1000) # updates playtime(seconds)
  display_playtime = stats_font.render(f"Playtime: {playtime}", False, "White") # updates playtime display
  display_fps = stats_font.render(f"FPS: {round(clock.get_fps())}", False, "White") # updates fps display